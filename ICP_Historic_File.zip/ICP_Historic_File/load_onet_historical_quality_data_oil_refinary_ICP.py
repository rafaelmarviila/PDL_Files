import pandas as pd
import datetime as dt
import re


# Please, use the file data availabe by PDL team.

df = pd.read_csv(r"ICP 2021.CSV", delimiter=';', low_memory=False)
df = pd.DataFrame(df)
plant_name = "Primavera do Leste"


colunas = {

'nhp_bruto_extracao_icp',
'nhp_bruto_refinaria_icp',
'nhp_day_tank_fosforo_ppm',
'nhp_day_tank_magnesio_ppm',
'nhp_day_tank_calcio_ppm',
'entrada_separadora_fosforo_ppm',
'entrada_separadora_magnesio_ppm',
'entrada_separadora_calcio_ppm',
'saida_separadora_fosforo_ppm',
'entrada_separadora_magnesio_ppm',
'entrada_separadora_calcio_ppm',
'saida_secador_fosforo_ppm',
'saida_secador_magnesio_ppm',
'saida_secador_calcio_ppm',
'clarificado_fosforo_ppm',
'clarificado_magnesio_ppm',
'clarificado_calcio_ppm',
'desodorizado_fosforo_ppm',
'desodorizado_magnesio_ppm',
'desodorizado_calcio_ppm'}

result_df = df.melt(id_vars="Data", value_vars=colunas, var_name="measurement_desc", value_name="pi_value1")
result_df["pi_value1"] = result_df['pi_value1'].str.replace(r"\(.*\)","")
result_df["plant_name"] = plant_name
result_df['Data'] = pd.to_datetime(result_df['Data'], format='%d/%m/%Y %H:%M').dt.strftime('%Y-%m-%d %H:%M:%S')
result_df = result_df.rename({'Data': 'pi_timestamp'}, axis=1)
result_df['pi_value1'] = result_df['pi_value1'].str.replace(',','.')
result_df = result_df.dropna()
result_df = result_df.drop_duplicates(subset=['pi_timestamp', 'measurement_desc'])
# Please, the file out needs to be uploaded in onet_tag_values_historical_tmp/Primavera_do_Leste hdfs path

result_df.to_csv("ICP_2021.CSV", sep='\t', index=0)